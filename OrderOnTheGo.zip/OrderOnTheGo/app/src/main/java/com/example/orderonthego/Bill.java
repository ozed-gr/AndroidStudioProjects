package com.example.orderonthego;

import android.nfc.Tag;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

public class Bill implements Parcelable
{
    private String date;
    private String header;
    private ArrayList<Pizza> pizzas = new ArrayList<Pizza>();

    public Bill()
    {
        Date date = new Date();
        this.date = date.toString();
    }

    //----------- Getters and Setters -----------------
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public int getNumbOfPizzas(){return  pizzas.size();}

    //---------Methods------------------------------------

    public String getAllPizzaDesc()
    {
        String pizza = null;
        int counter = 0;
        for (Pizza p: pizzas)
        {
            counter++;

            if(pizza == null) {
                pizza = p.getDescription(); continue;
            }

            pizza = pizza + "," + p.getDescription();

        }

        return pizza;
    }

    public double TotalCost()
    {
        double totalCost = 0;

        for (Pizza p: pizzas)
        {
            totalCost = totalCost + p.getPrice();
        }

        return totalCost;
    }

    public ArrayList<Pizza> getArray()
    {
        return pizzas;
    }

    public String getPizzaItems()
    {
        String pizzaList = "";

        if(pizzas.size() == 0)
        {

        }
        else
        {
            for (Pizza pizza : pizzas) {
                String pizzaDesc = pizza.getDescription();
                pizzaList = pizzaDesc + "\n";
            }
        }
        return pizzaList;
    }

    public void addPizza(Pizza p_pizza)
    {
        pizzas.add(p_pizza);
    }

    // ---------- Code for Parcelable interface ----------

    //Parcelable constructor puts together all parceled data back
    protected Bill(Parcel in)
    {
        Log.v("TAG", "ParcelData(Parcel source): time to put back parcel data");
        //Using the given class loader to load any enclosed Parcelables
        in.readList(pizzas, Pizza.class.getClassLoader());
        date = in.readString();
        header = in.readString();
    }

    //Un-flatten object
    public static final Creator<Bill> CREATOR = new Creator<Bill>()
    {
        @Override
        public Bill createFromParcel(Parcel in) {
            return new Bill(in);
        }

        @Override
        public Bill[] newArray(int size) {
            return new Bill[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        //writeList() will use writeValue(object) for each object in the list therefore calling
        //writeToParcel() from each object's class.
        dest.writeList(pizzas);
        dest.writeString(date);
        dest.writeString(header);
    }


}

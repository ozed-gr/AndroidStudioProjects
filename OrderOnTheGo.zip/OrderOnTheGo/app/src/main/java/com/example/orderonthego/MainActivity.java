package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity
{

    private Button btnTablesMenu;
    private Button btnMenu;
    private TextView txt_title;
    private TextView txt_author;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTablesMenu = findViewById(R.id.btn_tablesMenu);
        btnMenu = findViewById(R.id.btn_menu);
        txt_title = findViewById(R.id.txt_title);
        txt_author = findViewById(R.id.txt_author);

        btnTablesMenu.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveToTablesMenu();
            }
        });

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToMenu();
            }
        });



    }

    public void moveToTablesMenu()
    {
        Intent intent = new Intent(MainActivity.this, tables_menu.class);
        startActivity(intent);
    }

    public void moveToMenu()
    {
        Intent intent = new Intent(MainActivity.this, Menu_view_only.class);
        startActivity(intent);
    }


}
package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;

public class Menu extends AppCompatActivity
{
    public static final String EXTRA_SECOND = "TableBill";

    public Button btn_margarita;
    public Button btn_pepperoni;
    public Button btn_special;

    public Button btn_bill;
    public TextView txt_pizza;


    //It allows to create a String from an object or a list of objects,
    //then store that string into SharedPreferences. It can be retrieved
    //by using the same String and using the Gson methods to convert it
    //back from String to ArrayList.
    Gson gson;

    ArrayList<Tables> tablesWithOrders = new ArrayList<Tables>();
    Tables table;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_margarita = findViewById(R.id.btn_margarita);
        btn_pepperoni = findViewById(R.id.btn_pepperoni);
        btn_special = findViewById(R.id.btn_special);
        btn_bill = findViewById(R.id.btn_bill);

        txt_pizza = findViewById(R.id.txt_pizza);



        Log.d("TAG","Table Info started");
        Intent intent = getIntent();
        table = intent.getParcelableExtra("Table");


        loadData();

        //removeTable(table);

        Toast.makeText(Menu.this,"Open tables found: " + tablesWithOrders.size(),Toast.LENGTH_SHORT).show();



        //----------Methods-----------------------------------------



        btn_bill.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                double totalCost = table.bill.TotalCost();
                int size = table.bill.getNumbOfPizzas();
                String items = "";
                String name = table.getName();
                Date dateorderPosted = new Date();
                ArrayList<Pizza> pizzaArrayList = table.bill.getArray();
                items = table.bill.getAllPizzaDesc();
                Intent intent = new Intent(Menu.this, PaymentBill.class);
                intent.putExtra("items", items);
                intent.putExtra("size", size);
                intent.putExtra("name", name);
                intent.putExtra("date", dateorderPosted.toString());
                intent.putExtra("total", totalCost);
                //intent.putExtra("pizzas", pizzaArrayList);
                startActivity(intent);
            }
        });


        btn_margarita.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Margarita margarita = new Margarita();
                //table.bill.addPizza(margarita);
                table.bill.addPizza(margarita);

                Intent intent = new Intent(Menu.this, PaymentBill.class);

                saveData(table);
                Toast.makeText(Menu.this,"Margarita added",Toast.LENGTH_SHORT).show();


            }
        });

        btn_pepperoni.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Pepperoni pepperoni = new Pepperoni();
                table.bill.addPizza(pepperoni);
                Intent intent = new Intent(Menu.this, PaymentBill.class);

                saveData(table);
                Toast.makeText(Menu.this,"Pepperoni added",Toast.LENGTH_SHORT).show();
            }
        });

        btn_special.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Special special = new Special();
                table.bill.addPizza(special);
                Intent intent = new Intent(Menu.this, PaymentBill.class);

                saveData(table);
                Toast.makeText(Menu.this,"Special added",Toast.LENGTH_SHORT).show();

            }
        });


    }

    //Will save tablesWithOrders into the SharedPreferences
    public void saveData(Tables tb)
    {
        boolean found = false;

        for (Tables dummy : tablesWithOrders)
        {
            if(dummy.getName().equals(tb.getName()))
            {
                found = true;
            }
        }

        if(found == false){ tablesWithOrders.add(tb); }

        SharedPreferences sharedPreferences = getSharedPreferences("SharedPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gsonSave = new Gson();
        //Will contain our arrayList in json form
        String json = gsonSave.toJson(tablesWithOrders);
        //Uses key to identify object
        editor.putString("TablesWithOrders", json);
        //Save happens here
        editor.apply();
    }

    public void loadData()
    {
        SharedPreferences sharedPreferences = getSharedPreferences("SharedPreferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("TablesWithOrders", "");
        Type type = new TypeToken<ArrayList<Tables>>(){}.getType();
        //List<Tables> tablesLoad = gsonLoad.fromJson(json, tablesWithOrders.getClass());
        tablesWithOrders = gson.fromJson(json, type);

        if(tablesWithOrders == null)
        {
            tablesWithOrders = new ArrayList<>();
        }

    }

    public void removeTable(Tables tb)
    {
        int position = 0;
        boolean found = false;

        for (Tables dummy : tablesWithOrders)
        {
            if(dummy.getName().equals(tb.getName()))
            {
               position = tablesWithOrders.indexOf(dummy);
               found = true;
            }
        }

        if(found == true)
        {
            tablesWithOrders.remove(position);

            SharedPreferences sharedPreferences = getSharedPreferences("SharedPreferences", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            Gson gsonSave = new Gson();
            //Will contain our arrayList in json form
            String json = gsonSave.toJson(tablesWithOrders);
            //Uses key to identify object
            editor.putString("TablesWithOrders", json);
            //Save happens here
            editor.apply();
        }

    }

    public void removeAll()
    {
        SharedPreferences sharedPreferences = getSharedPreferences("SharedPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }

    //Get table object from arrayList
    public Tables getTable(Tables tb)
    {
        int position;
        Tables table = null;

        for (Tables dummy : tablesWithOrders)
        {
            if(dummy.getName().equals(tb.getName()))
            {
                position = tablesWithOrders.indexOf(dummy);
                table = tablesWithOrders.get(position);
            }
        }

        return table;
    }



}

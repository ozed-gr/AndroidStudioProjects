package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Menu_view_only extends AppCompatActivity
{
    private Button btn_margarita;
    private Button btn_pepperoni;
    private Button btn_special;
    private TextView txt_pizza;
    private TextView txt_menu;
    private TextView txt_marCost;
    private TextView txt_pepCost;
    private TextView txt_speCost;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_view_only);

        btn_margarita = findViewById(R.id.btn_margarita);
        btn_pepperoni = findViewById(R.id.btn_pepperoni);
        btn_special = findViewById(R.id.btn_special);
        txt_pizza = findViewById(R.id.txt_pizza);
        txt_menu = findViewById(R.id.txt_menu);
        txt_marCost = findViewById(R.id.txt_marCost);
        txt_pepCost = findViewById(R.id.txt_pepCost);
        txt_speCost = findViewById(R.id.txt_speCost);


    }
}

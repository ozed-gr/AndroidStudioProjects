package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class PaymentBill extends AppCompatActivity
{
    public static final String EXTRA_SECOND = "TableBill";

    public Button btn_pay;

    public TextView txt_tableName;
    public TextView txt_time;
    public TextView txt_itemList1;
    public TextView txt_itemList2;
    public TextView txt_itemList3;
    public TextView txt_itemList4;
    public TextView txt_itemList5;
    public TextView txt_itemList6;

    public TextView txt_totalLabel;
    public TextView txt_total;
    public TextView txt_separator1;
    public TextView txt_separator2;

    Tables table = null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_bill);

        txt_tableName = findViewById(R.id.txt_tableName);
        txt_time = findViewById(R.id.txt_time);
        txt_totalLabel = findViewById(R.id.txt_totalLabel);
        txt_total = findViewById(R.id.txt_total);
        txt_itemList1 = findViewById(R.id.txt_itemList1);
        txt_itemList2 = findViewById(R.id.txt_itemList2);
        txt_itemList3 = findViewById(R.id.txt_itemList3);
        txt_itemList4 = findViewById(R.id.txt_itemList4);
        txt_itemList5 = findViewById(R.id.txt_itemList5);
        txt_itemList6 = findViewById(R.id.txt_itemList6);


        //btn_pay = findViewById(R.id.btn_pay);

        Intent intent = getIntent();
        //Intent
        String items = ""; //= intent.getParcelableExtra("items");
        String name = "";
        String date = "";
        double total = 0.0;
        //ArrayList<Pizza> pArray = new ArrayList<>();
        int numbOfPizzas = 0;
        Bundle extras = intent.getExtras();
        if(extras != null) {
            items = extras.getString("items");
            numbOfPizzas = extras.getInt("size");
            name = extras.getString("name");
            date = extras.getString("date");
            total = extras.getDouble("total");
        }

        //pArray = intent.getParcelableArrayListExtra("pizzas");


       // String tableName = table.getName();
        //String tableSize = "People: " + table.getSizeOfPeople();

        //String listItems = table.bill.ge
        // PizzaItems();
        String[] arrOfStr = items.split(",", numbOfPizzas);
        //int a = arrOfStr.length;
        boolean b = false;


        txt_itemList1.setText("___________________________________");
        txt_itemList2.setText("___________________________________");
        txt_itemList3.setText("___________________________________");
        txt_itemList4.setText("___________________________________");
        txt_itemList5.setText("___________________________________");
        txt_itemList6.setText("___________________________________");

       for(int i=0; i<arrOfStr.length; i++)
       {
           String str = "";
           str = arrOfStr[i];
           if(i==0){txt_itemList1.setText(str); continue;}
           if(i==1){txt_itemList2.setText(str); continue;}
           if(i==2){txt_itemList3.setText(str); continue;}
           if(i==3){txt_itemList4.setText(str); continue;}
           if(i==4){txt_itemList5.setText(str); continue;}
           if(i==5){txt_itemList6.setText(str);}
       }


        txt_tableName.setText(name);
        txt_time.setText(date);
        txt_total.setText("£ "+ Double.toString(total));

        /*
        btn_pay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveToPaymentMethods();
            }
        });

         */



    }

    public void moveToPaymentMethods()
    {
        Intent intent = new Intent(PaymentBill.this, Payment_Methods.class);
        startActivity(intent);
    }

    public void tableItemsToString(Tables table)
    {
        //for(int i=0; i<table.bill.)
    }

}

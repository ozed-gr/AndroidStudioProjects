package com.example.orderonthego;


import android.os.Parcel;

public class Pepperoni extends Pizza
{

    public Pepperoni()
    {
        description = "Pepperoni";
        price = 10.00;
    }

    //----------- Getters and Setters -----------------
    @Override
    public String getDescription()
    {
        return description = "Pepperoni";
    }

    @Override
    public double getPrice()
    {
        return price = 10.00;
    }

    //---------Methods------------------------------------


    // ---------- Code for Parcelable interface ----------

    protected Pepperoni(Parcel in)
    {
        super(in);
        description = in.readString();
        price = in.readDouble();
    }

    //Un-flatten object
    public static final Creator<Pepperoni> CREATOR = new Creator<Pepperoni>() {
        @Override
        public Pepperoni createFromParcel(Parcel in) {
            return new Pepperoni(in);
        }

        @Override
        public Pepperoni[] newArray(int size) {
            return new Pepperoni[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        super.writeToParcel(dest, flags);
    }

}

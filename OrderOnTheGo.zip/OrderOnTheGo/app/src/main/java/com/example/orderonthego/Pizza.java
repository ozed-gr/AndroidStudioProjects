package com.example.orderonthego;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class Pizza implements Parcelable
{

    protected String description;
    protected double price;

    /*
    protected Pizza(String desc, double cost)
    {
        description = desc;
        price = cost;
    }

     */

    protected Pizza(){};

    //Parcelable constructor puts together all parceled data back
    protected Pizza(Parcel in)
    {
        description = in.readString();
        price = in.readDouble();
    }

    //Un-flatten object
    public static final Creator<Pizza> CREATOR = new Creator<Pizza>() {
        @Override
        public Pizza createFromParcel(Parcel in) {
            return new Pizza(in);
        }

        @Override
        public Pizza[] newArray(int size) {
            return new Pizza[size];
        }
    };


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }


    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeString(description);
        dest.writeDouble(price);
    }

}

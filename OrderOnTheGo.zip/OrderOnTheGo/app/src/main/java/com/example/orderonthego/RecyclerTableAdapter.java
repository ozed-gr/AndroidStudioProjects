package com.example.orderonthego;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerTableAdapter extends RecyclerView.Adapter<RecyclerTableAdapter.ViewHolder>
{
    ArrayList<Tables> tablesArrayList = new ArrayList<Tables>();
    Context context;

    public RecyclerTableAdapter(Context ct, ArrayList<Tables> tables)
    {
        tablesArrayList = tables;
        context = ct;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView image;
        public TextView textView;
        public RelativeLayout parentLayout;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            image = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.txt_tableName);
            parentLayout = itemView.findViewById(R.id.parentLayout);
        }

    }

    @NonNull
    @Override
    //responsible for filling in the view
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.table_item_cardview, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position)
    {
        Tables selectedTable = tablesArrayList.get(position);
        holder.textView.setText(selectedTable.getName());

        holder.parentLayout.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                Log.d("TAG","onClick: clicked on: " + tablesArrayList.get(position));
                Intent intent = new Intent(context, TableInfo.class);
                intent.putExtra("Table", tablesArrayList.get(position));

                Log.d("TAG","Calling Second Activity");
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return tablesArrayList.size();
    }





}

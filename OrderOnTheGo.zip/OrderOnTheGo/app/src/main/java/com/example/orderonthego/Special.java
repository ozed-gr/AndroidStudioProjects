package com.example.orderonthego;

import android.os.Parcel;

public class Special extends Pizza
{
    public Special()
    {
        description = "Special";
        price = 14.00;
    }

    //----------- Getters and Setters -----------------
    @Override
    public String getDescription()
    {
        return description = "Special";
    }

    @Override
    public double getPrice()
    {
        return price = 14.00;
    }

    //---------Methods------------------------------------


    // ---------- Code for Parcelable interface ----------

    protected Special(Parcel in)
    {
        super(in);
        description = in.readString();
        price = in.readDouble();
    }

    //Un-flatten object
    public static final Creator<Special> CREATOR = new Creator<Special>() {
        @Override
        public Special createFromParcel(Parcel in) {
            return new Special(in);
        }

        @Override
        public Special[] newArray(int size) {
            return new Special[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        super.writeToParcel(dest, flags);
    }
}

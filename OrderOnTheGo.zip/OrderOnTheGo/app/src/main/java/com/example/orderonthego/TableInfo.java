package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TableInfo extends AppCompatActivity {

    public TextView txt_tableName;
    public TextView txt_tableSize;
    public Button btn_order;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_info);

        //Receive Table Object from previous Intent
        Log.d("TAG","Table Info started");
        Intent intent = getIntent();
        final Tables table = intent.getParcelableExtra("Table");

        String tableName = table.getName();
        String tableSize = "People: " + table.getSizeOfPeople();

        final String date = table.bill.getDate();


        txt_tableName = findViewById(R.id.txt_tableName);
        txt_tableName.setText(tableName);

        txt_tableSize = findViewById(R.id.txt_tableSize);
        txt_tableSize.setText(tableSize);

        btn_order = findViewById(R.id.btn_order);


        Log.d("TAG","Move to Menu");
        btn_order.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(TableInfo.this, Menu.class);
                intent.putExtra("Table", table);
                intent.putExtra("Table Order Time", date);
                startActivity(intent);
            }
        });



    }
}

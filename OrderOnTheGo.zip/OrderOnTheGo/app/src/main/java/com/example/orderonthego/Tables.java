package com.example.orderonthego;

import android.os.Parcel;
import android.os.Parcelable;

public class Tables implements Parcelable
{

    protected Bill bill = new Bill();
    private String name;
    private String sizeOfPeople;


    public Tables(Bill bill, String name, String sizeOfPeople)
    {
        this.bill = bill;
        this.name = name;
        this.sizeOfPeople = sizeOfPeople;
    }

    //Parcelable constructor
    protected Tables(Parcel in)
    {
        bill = in.readParcelable(Bill.class.getClassLoader());
        name = in.readString();
        sizeOfPeople = in.readString();
    }

    public static final Creator<Tables> CREATOR = new Creator<Tables>() {
        @Override
        public Tables createFromParcel(Parcel in) {
            return new Tables(in);
        }

        @Override
        public Tables[] newArray(int size) {
            return new Tables[size];
        }
    };

    public Bill getBill() {
        return bill;
    }

    public void setBill(Bill bill) {
        this.bill = bill;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSizeOfPeople() {
        return sizeOfPeople;
    }

    public void setSizeOfPeople(String sizeOfPeople) {
        this.sizeOfPeople = sizeOfPeople;
    }


    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeParcelable(bill, flags);
        dest.writeString(name);
        dest.writeString(sizeOfPeople);
    }
}

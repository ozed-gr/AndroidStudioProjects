package com.example.orderonthego;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.orderonthego.Bill;
import com.example.orderonthego.R;
import com.example.orderonthego.RecyclerTableAdapter;
import com.example.orderonthego.Tables;

import java.util.ArrayList;

public class tables_menu extends AppCompatActivity
{

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayout;

    ArrayList<Tables> tablesArrayList = new ArrayList<Tables>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tables_menu);

        //Initialise array
        tablesArrayList.add(new Tables(new Bill(), "Table 1", "2"));
        tablesArrayList.add(new Tables(new Bill(), "Table 2", "4"));
        tablesArrayList.add(new Tables(new Bill(), "Table 3", "6"));
        tablesArrayList.add(new Tables(new Bill(), "Table 4", "2"));
        tablesArrayList.add(new Tables(new Bill(), "Table 5", "5"));
        tablesArrayList.add(new Tables(new Bill(), "Table 6", "3"));
        tablesArrayList.add(new Tables(new Bill(), "Table 7", "2"));
        tablesArrayList.add(new Tables(new Bill(), "Table 8", "2"));

        mRecyclerView = findViewById(R.id.rec_tables);
        //improves performance by specifying that the recycler view will not change its size
        mRecyclerView.setHasFixedSize(true);
        mLayout = new LinearLayoutManager(this);
        //this list gets passed to our adapter which then provides it to the view holder
        mAdapter = new RecyclerTableAdapter(this,tablesArrayList);
        mRecyclerView.setLayoutManager(mLayout);
        mRecyclerView.setAdapter(mAdapter);



    }
}
